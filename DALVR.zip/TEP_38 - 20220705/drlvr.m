function [B,Q,A,P,W,C]=drlvr(X1,Y1,a,s,kappa)

%Function drlvr -- Performs DrLVR regression on an autoscaled data sets

% Inputs:        
% X -- the input data matrix
% Y -- the output data matrix
% a -- the number of latent variables
% s -- lags
% kappa -- the parameter of regularization term

% Outputs:
% B0 -- regression coefficient matrix

[n,m]=size(X1); np=size(Y1,2);
N=n-s;

% ———— Initialize ————
X=X1;Y=Y1;
u=Y(:,1);
us_0=u(s+1:n,1);
beta=ones(s+1,1); beta=beta/norm(beta); 

for i=1:a
    tol=1;count=0;
    while tol > 1e-4 && count < 1000 
        % iterate until convergence of t or max number of iterations (1000) reached
        count = count+1;
        % ———— Outer structure ————
        % Formulate X_beta Ys
        X_beta = zeros(n-s,m);
        for j = 0:s
            X_beta = X_beta + beta(j+1,:) * X(s+1-j:n-j,:);
        end
        Ys = Y(s+1:n,:);   
        
        % Calculate w
        w=pinv(X_beta'*X_beta+kappa*eye(size(X_beta'*X_beta)))*X_beta'*us_0;
        % w = (X_beta'*X_beta+kappa*eye(size(X_beta'*X_beta)))\(X_beta'*us_0);
        %w=w/norm(X_beta*w);
        
        % Calculate Ts
        t=X*w;

        Ts=zeros(n-s,s+1);
        for j=0:s
            Ts(:,j+1)=t(s+1-j:n-j,:);
        end
        
        % Calculate q
        q=Ys'*Ts*beta;
        q=q/norm(q);   
        
        % Obtain us
        u=Y*q;
        us=Ys*q; 
        
        % Update beta
        %beta=pinv(Ts'*Ts+kappa*eye(size(Ts'*Ts)))*Ts'*us;
        beta=(Ts'*Ts+kappa*eye(size(Ts'*Ts)))\(Ts'*us);
        beta=beta/norm(beta);  
        beta=beta/norm(Ts*beta); 
        
        tol=(us-us_0)'*(us-us_0);
        us_0=us;
    end
    
    % ———— Inner structure ————
    % Calculate inner model relation between Ts and us
    %alpha=pinv(Ts'*Ts+kappa*eye(size(Ts'*Ts)))*Ts'*us;
    alpha=(Ts'*Ts+kappa*eye(size(Ts'*Ts)))\(Ts'*us);
    
    % ———— Deflation ————
    us_hat=Ts*alpha; Us(:,i)=us_hat;
    p=X'*t/(t'*t); P(:,i)=p;
    c=Ys'*us_hat/(us_hat'*us_hat); C(:,i)=c;
    X=X-t*p';
    %Y(1:s,:)=Y(1:s,:)-b*t(1:s,:)*q'; Y(s+1:n,:)=Y(s+1:n,:)-us_hat*c';
    Y(1:s,:)=Y(1:s,:)-t(1:s,:)*c'; Y(s+1:n,:)=Y(s+1:n,:)-us_hat*c';
    
 
    %Ys=Ys-us_hat*c';
    T(:,i)=t; Q(:,i)=q; W(:,i)=w; A(:,i)=alpha; B(:,i)=beta; 
end
end