%% ———— DrLVR-ARX ————
function [P, Q, C, W, Beta, Delta, Y1_debug] = darlvr(U1,Y1,a,gamma_w,gamma_beta,gamma_delta,s,d)

% U1 -- autoscaled input matrix of training data
% Y1 -- autoscaled output matrix of training data
% X1_test -- autoscaled input matrix of testing data
% a -- the number of principal components determined by cross-validation
% s -- the lag parameter to denote the degree of dynamics corresponding to input (t)
% d -- the lag parameter to denote the degree of dynamics corresponding to output (u)
% kappa -- the regularization term

[n,m] = size(U1); np = size(Y1,2);
g = max(s,d); N = n - g; 
Y1_debug = zeros(n,np); 

% ———— Initialize beta and sigma, and u_s as some column of Y0
% Initialize beta and sigma
beta = ones(s+1,1); beta = beta/norm(beta);
delta = ones(d,1); delta = delta/norm(delta);
w = ones(m,1); w = w/norm(w);

% Initialize ug as some column of Y1
v = Y1(:,1); vg = v(g+1:N+g);
l = 0;
W = zeros(0,0); P = zeros(0,0); Q = zeros(0,0); C = zeros(0,0);
Beta = zeros(0,0); Delta = zeros(0,0); B = zeros(0);

for l = 1:a
    % Dynamic outer modeling
    iter = 0;
    while true
        temp_beta = beta;
        temp_delta = delta;
        temp_vg = vg;
        
        % Form U_beta and Y_sigma
        U_beta = zeros(N, m);
        for i = 0:s
            U_beta = U_beta + beta(i+1) * U1(g-i+1:g-i+N,:);
        end
        
        Y_delta = zeros(N,np);
        for i = 1:d
            Y_delta = Y_delta + delta(i) * Y1(g-i+1:g-i+N,:);
        end
        
        Yg = Y1(g+1:N+g,:);
        % Form Ts and Ud
        t = U1 * w;        
        Ts = zeros(N,s+1);
        for i = 0:s
            Ts(:,i+1) = t(s-i+1:s-i+N,:);
        end
        
        Vd = zeros(N,d);
        for i = 1:d
            Vd(:,i) = v(g-i+1:g-i+N,:);
        end
        
        lambda_w_beta = w' * U_beta' * vg - gamma_w * (norm(w))^2;
        kappa_w = gamma_w / lambda_w_beta;
        w = pinv(U_beta'* U_beta + kappa_w * eye(m)) * U_beta'* vg;
        w = w / norm(U_beta * w);
        
        %q = Yg'* (Ts * beta + Vd * delta) + Y_delta'*vg - (delta' * Vd' * vg - gamma_delta * (norm(delta))^2) * Y_delta' * Vd * delta;
        lambda_q = vg'* Vd *delta + vg'* Ts * beta + gamma_delta * (norm(delta))^2;
        lambda_q_delta = delta'* Vd'* vg - gamma_delta * (norm(delta))^2;
        kappa_q = lambda_q / lambda_q_delta;
        q = pinv(Y_delta'* Y_delta + kappa_q * eye(np)) * (Yg'* Vd * delta + Yg'* Ts * beta + Y_delta'* vg);
        q = q / norm(q);
        
        v = Y1 * q; vg = Yg * q;   
        
        kappa_beta = gamma_beta / lambda_w_beta;
        beta = pinv(Ts'*Ts + kappa_beta * eye(s+1)) * Ts' * vg; 
        %beta = beta / norm(Ts * beta);
        
        % lambda_q_delta = delta' * Vd' * vg - gamma_delta * (norm(delta))^2;
        kappa_delta = gamma_delta / lambda_q_delta;
        delta = pinv(Vd'*Vd + kappa_delta * eye(d)) * Vd' * vg; 
        delta = delta / norm(Vd * delta);
        
        if norm(temp_beta - beta) < 1e-6 || norm(temp_beta + beta) < 1e-6
        %if norm(temp_delta - delta) < 1e-6 || norm(temp_delta + delta) < 1e-6
        %if norm(temp_vg - vg) < 1e-6 || norm(temp_vg + vg) < 1e-6
            break;
        end
        
        iter = iter + 1;
        if iter > 1000
            fprintf('---- DrLVR-ARX Iterations ---a: %d, s: %d, d, %d\n', a, s, d);
            break;
        end
    end
    
    %% ———— Dynamic inner modeling ————
    %data = [v,t];
    %opt = arxOptions('InputOffset', 1); sys = arx(data,[d s+1 1],opt);
    %sys = arx(data,[d s+1 1]);
    %alpha_hat = sys.B;
    %alpha_hat = alpha_hat(2:length(alpha_hat))';
    %gama_hat = sys.A;
    %gama_hat = gama_hat(2:length(gama_hat))';
    %ug_hat = Ts*alpha_hat + Vd*gama_hat;    
    
    
    ug_hat = Ts*beta + Vd*delta;
    
   %% ———— Deflation ———— 
    p = U1'*t/(t'*t);
    c = Yg'*ug_hat/(ug_hat'*ug_hat);
    
    U1 = U1 - t*p';
    
    Y1(1:g, :) = Y1(1:g, :) - t(1:g)*c';
    Y1(g+1:n,:) = Y1(g+1:n, :) - ug_hat * c';
    
    Y1_debug(g+1:n,:) = Y1_debug(g+1:n,:) + ug_hat * c';
    
    l = l + 1;    
    P = [P p]; Q = [Q q]; C = [C c]; W = [W w];
    Beta = [Beta beta]; Delta = [Delta delta]; 
end