function [r, t, p, q, lamda,n,m,level,T2_lim,Q_lim] = rlvr_train(X0,Y0,a,k)

% this function trains LVR
% X0,Y0 must be autoscaled
% a is the number of LVR factors
% a can be obtained by running pls_factor.m, which uses cross-validation

[n,m] = size(X0);
np=size(Y0,2);

%% ———— LVR ————
% a -- number of LVR factors

[t,p,q,w] =rlvr(X0,Y0,a,k);
r = w*pinv(p'*w);
lamda = 1/(n-1)*t'*t;

%% ———— LVR control limit for detection ————
alpha=0.01; level=1-alpha; 
% ———— T2_lim ————
T2_lim=(a*(n^2-1)/(n*(n-a)))*finv(level,a,n-a) 

% ———— Q_lim ————
% val=var(X0); 
% theta_1=zeros(1,m); theta_2=zeros(1,m); 
% for i_Q=(a+1):m
%    theta_1(i_Q)=(val(i_Q))^2;
%    theta_2(i_Q)=val(i_Q);
% end
% g=sum(theta_1)/sum(theta_2); h=(sum(theta_2))^2/sum(theta_1);

for i = 1:n
    xc=X0(i,:)';
    % x_k=(eye(size(p*r'))-p*r')*xc; Q_index(i)=x_k'*x_k; % LVR可行
    Q_index(i)=xc'*(eye(size(p*r'))-p*r')*xc;
end
a=mean(Q_index); b=var(Q_index);
g=b/(2*a); h=2*a^2/b;
Q_lim=g*chi2inv(level,h)

%[T2_lim,Q_lim];
