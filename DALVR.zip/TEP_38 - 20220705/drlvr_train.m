function [R,B1,Q,A,P,W,C,Lambda,T2_lim,Q_lim] = drlvr_train(X1,Y1,a,s,kappa)
% this function trains DLVR
% X1 -- autoscaled input matrix of training data
% Y1 -- autoscaled output matrix of training data
% X1_test -- autoscaled input matrix of testing data
% a -- the number of principal components determined by cross-validation
% s -- the lag parameter to denote the degree of dynamics

n = size(X1,1); N = n - s;

%% ———— DrLVR ————
[B1,Q,A,P,W,C] = drlvr(X1,Y1,a,s,kappa);
R = W*pinv(P'*W);
T = X1*R;
Lambda = 1/(n-1)*T'*T;

%% ———— DLVR control limit for detection ————
alpha = 0.05; level = 1 - alpha; 

% ———— T2_lim ————
%T2_lim = (a*(N^2-1)/(N*(N-a))) * finv(level,a,N-a); 
T2_lim = chi2inv(level,a);

% ———— Q_lim ————
for i = 1:n
    x = X1(i,:)';
    Q_index(i) = x'*(eye(size(P*R')) - P*R')*x;
    %xc = (eye(size(P*R'))-P*R')*x; Q_index(i) = xc'*xc; 
end
a = mean(Q_index); b = var(Q_index); g = b/(2*a); h = 2*a^2/b;
Q_lim = g*chi2inv(level,h);