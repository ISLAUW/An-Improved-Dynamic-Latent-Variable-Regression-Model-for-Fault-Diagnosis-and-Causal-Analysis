clear all;
close all;
clc;

%% ———— Autoscale the data ————
% ———— Training Data: Normal Data ————
load d00.dat;  % 52*500 % 每一列为一个指标，每一行为一个样本
% An observation vector at a particular time instant is given by
% x=[XMEAS(1), XMEAS(2), ..., XMEAS(41), XMV(1), ..., XMV(11)]^T
% where XMEAS(n) is the n-th measured variable and XMV(n) is the n-th manipulated variable.
n=size(d00,2)/2;

% ———— 数据采样 ————
X0=zeros(n,33); Y0=zeros(n,2); 
for i=1:n
    X0(i,:)=[d00(1:22,(2*i))',d00(42:52,(2*i))']; 
    Y0(i,:)=d00(35:36,(2*i))';
end

X0=autos(X0); Y0=autos(Y0);

[a,k]=rlvr_factor(X0,Y0);
k=0.001*k;

save rlvr_factor_data a k