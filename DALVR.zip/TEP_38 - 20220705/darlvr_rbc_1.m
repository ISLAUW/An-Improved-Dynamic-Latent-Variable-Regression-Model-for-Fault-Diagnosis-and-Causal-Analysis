function [R,Q,Alpha,P,W,C,Gama,Lambda, ksi, RBC_T2_t, RBC_Q_t, RBC_phi_t, RBC_rate_T2, RBC_rate_Q, RBC_rate_phi,RBC_index_T2,RBC_index_Q,RBC_index_phi, ...
   RBC_T2_lim, RBC_Q_lim, RBC_phi_lim] = darlvr_rbc(U1,Y1,U1_test, Y1_test, a,gamma_w,gamma_beta,gamma_delta,s,d)

% this function trains DArLVR
% U1 -- autoscaled input matrix of training data
% Y1 -- autoscaled output matrix of training data
% U1_test -- autoscaled input matrix of testing data
% a -- the number of principal components determined by cross-validation
% s -- the lag parameter to denote the degree of cross-correlations
% d -- the lag parameter to denote the degree of auto-correlations

[n,m] = size(U1); np = size(Y1,2);
n_test = size(U1_test,1);
g = max(s,d); N = n - g; Nt = n_test - g;

%% ———— DALVR ————
[P,Q,C,W,Alpha,Gama] = darlvr(U1,Y1,a,gamma_w,gamma_beta,gamma_delta,s,d);
R = W * pinv(P'*W);
T = U1* R;
Lambda = 1/(n-1) * T'* T;

%% ———— Reconstruction-Based Contribution (RBC) ————
alpha = 0.01; level = 1 - alpha;

M_T2 = R * pinv(Lambda) * R'; % T2
M_Q = (eye(size(P*R'))-P*R'); % SPE

% ———— Control Limits ————
T2_lim = chi2inv(level,a);

U_beta = zeros(N, m);
for l = 1:a
    for i = 0:s
        U_beta = U_beta + Alpha(i+1,l) * U1(g-i+1:g-i+N,:);
    end
end

for k = 1:N
    u = U_beta(k,:)';
    Q_index(k) = u'* M_Q * u;
end
a_q = mean(Q_index); b_q = var(Q_index); 
g_q = b_q/(2*a_q); h_q = 2*a_q^2/b_q;
Q_lim = g_q * chi2inv(level,h_q);

M_phi = M_T2/T2_lim + M_Q/Q_lim; % phi

Ut_beta = zeros(Nt,m);
for l = 1:a
    for i = 0:s
        Ut_beta = Ut_beta + Alpha(i+1,l) * U1_test(g-i+1:g-i+Nt,:);
    end
end

S = 1/(Nt-1)* U_beta'* U_beta;

g_phi = trace((S * M_phi)^2)/trace(S * M_phi);
h_phi = (trace(S * M_phi))^2/trace((S * M_phi)^2);
phi_lim = g_phi * chi2inv(level,h_phi);

%ksi
ksi = zeros (m,m);
for i = 1:m
    ksi(i,i) = 1;
end

for k = 1:Nt
    ut_beta = 0;
    for j = 0:s
        ut_beta = ut_beta + Alpha(j+1,a) * U1_test(g-j+1:g-j+Nt,:)';
    end
end

RBC_T2 = zeros(n_test,m); RBC_Q = zeros(n_test,m); RBC_phi = zeros(n_test,m); 
for i = 1:m
    ksi_i = ksi(i,:)';
    for k= 1:s
        u = U1_test(k,:)';
        RBC_T2(k,i) = u'* M_T2 * ksi_i * pinv(ksi_i'* M_T2 * ksi_i) *ksi_i' * M_T2 * u;
        RBC_Q(k,i) = u'* M_Q * ksi_i * pinv(ksi_i'* M_Q * ksi_i) *ksi_i' * M_Q * u;
        RBC_phi(k,i) = (u'* M_phi * ksi_i * pinv(ksi_i'* M_phi * ksi_i) *ksi_i' * M_phi * u);
    end      
    for k = 1:Nt
        u = ut_beta(:,k);
        RBC_T2(k+s,i) = u'* M_T2 * ksi_i * pinv(ksi_i'* M_T2 * ksi_i) *ksi_i' * M_T2 * u;
        RBC_Q(k+s,i) = u'* M_Q * ksi_i * pinv(ksi_i'* M_Q * ksi_i) *ksi_i' * M_Q * u;
        RBC_phi(k+s,i) = (u'* M_phi * ksi_i * pinv(ksi_i'* M_phi * ksi_i) *ksi_i' * M_phi * u);
        
        %RBC_T2(k,i) = (ksi_i' * M_T2 * u)^2 / (ksi_i'* M_T2 * ksi_i);
        %RBC_Q(k,i) = (ksi_i' * M_Q * u)^2 / (ksi_i'* M_Q * ksi_i);
        %RBC_phi(k,i) = (ksi_i' * M_phi * u)^2 / (ksi_i'* M_phi * ksi_i);   
    end
    %S = cov(ut_beta');
    S = 1/(n_test-1)* u * u';
    g_rt2(i) = trace((S * M_T2 * ksi_i * pinv(ksi_i'* M_T2 * ksi_i) * ksi_i' * M_T2)^2) / trace(S * M_T2 * ksi_i * pinv(ksi_i'* M_T2 * ksi_i) * ksi_i' * M_T2);
    h_rt2(i) = (trace(S * M_T2 * ksi_i * pinv(ksi_i'* M_T2 * ksi_i) * ksi_i' * M_T2))^2 / trace((S * M_T2 * ksi_i * pinv(ksi_i'* M_T2 * ksi_i) * ksi_i' * M_T2)^2);
    RBC_T2_lim(i) = abs(g_rt2(i) * chi2inv(level,h_rt2(i)));
    
    g_rq(i) = trace((S * M_Q * ksi_i * pinv(ksi_i'* M_Q * ksi_i) * ksi_i' * M_Q)^2) / trace(S * M_Q * ksi_i * pinv(ksi_i'* M_Q * ksi_i) * ksi_i' * M_Q);
    h_rq(i) = (trace(S * M_Q * ksi_i * pinv(ksi_i'* M_Q * ksi_i) * ksi_i' * M_Q))^2 / trace((S * M_Q * ksi_i * pinv(ksi_i'* M_Q * ksi_i) * ksi_i' * M_Q)^2);    
    RBC_Q_lim(i) = abs(g_rq(i) * chi2inv(level,h_rq(i)));
    
    g_rp(i) = trace((S * M_phi * ksi_i * pinv(ksi_i'* M_phi * ksi_i) * ksi_i' * M_phi)^2) / trace(S * M_phi * ksi_i * pinv(ksi_i'* M_phi * ksi_i) * ksi_i' * M_phi);
    h_rp(i) = (trace(S * M_phi * ksi_i * pinv(ksi_i'* M_phi * ksi_i) * ksi_i' * M_phi))^2 / trace((S * M_phi * ksi_i * pinv(ksi_i'* M_phi * ksi_i) * ksi_i' * M_phi)^2);
    RBC_phi_lim(i) = abs(g_rp(i) * chi2inv(level,h_rp(i)));
    
    RBC_T2_t(i) = sum(RBC_T2(:,i));
    RBC_Q_t(i) = sum(RBC_Q(:,i));
    RBC_phi_t(i) =sum(RBC_phi(:,i));
end

for i = 1:m
    
    count_T2 = 0; count_Q = 0; count_phi = 0;
    
    for k = 1:n_test
        if RBC_T2(k,i) > RBC_T2_lim(i)
            count_T2 = count_T2 + 1;
        end
        
        if RBC_Q(k,i) > RBC_Q_lim(i)
            count_Q = count_Q + 1;
        end
        
        if RBC_phi(k,i) > RBC_phi_lim(i)
            count_phi = count_phi + 1;
        end
           
    end
     
    RBC_index_T2(i) = count_T2;
    RBC_index_Q(i) = count_Q;
    RBC_index_phi(i) = count_phi; 
    
    RBC_rate_T2(i) = count_T2 / n_test;
    RBC_rate_Q(i) = count_Q / n_test;
    RBC_rate_phi(i) = count_phi / n_test;       
end
