clear all
clc
close all
format short;
tic

%% ———— Data ————
% ———— Training Data: Fault 3 ————
load Numerical_Simulation.mat
X0 = X_f0; Y0 = Y_f0; 
X0_test = X_f3; Y0_test = Y_f3;

% ———— Autoscale the training data and testing data ————
[X1,mx_train,vx_train] = autos(X0);
[Y1,my_train,vy_train] = autos(Y0);

X1_test = autos_test(X0_test,mx_train,vx_train);
Y1_test = autos_test(Y0_test,my_train,vy_train);

[n_train,m] = size(X1);
n_test = size(X1_test,1);



%% ———— Parameter Determination————
load darlvr_factor_data.mat
f = fault;
a = 2; s = 2; d = 2;

%% ———— MSE ————
g = max(s,d); 
[P,Q,C,W,Beta,Delta,Y1_debug] = darlvr(X1,Y1,a,gamma_w,gamma_beta,gamma_delta,s,d);

% ———— MSE for Training Data ————
[Y1_predict,Y1xg_predict,Y1yg_predict] = darlvr_predict(X1,Y1,X1,Y1,a,gamma_w,gamma_beta,gamma_delta,s,d);
[MSE_Y1,MSE_Y1xg,MSE_Y1yg] = darlvr_mse(X1,Y1,X1,Y1,a,gamma_w,gamma_beta,gamma_delta,s,d);

% ———— MSE for Testing Data ————
[Y_predict,Yxg_predict,Yyg_predict] = darlvr_predict(X1,Y1,X1_test,Y1_test,a,gamma_w,gamma_beta,gamma_delta,s,d);
[MSE_overall,MSE_Yxg,MSE_Yyg] = darlvr_mse(X1,Y1,X1_test,Y1_test,a,gamma_w,gamma_beta,gamma_delta,s,d);

%% ———— Plotting ———— 
% ———— Training data ————
%figure;
%subplot(3,1,1);
%plot([1:400], [Y1(1:200,:)',Y1(1:200,:)'],'b');
%hold on
%plot([201:400], Y1_predict(1:200,:),'r');
%legend('Actual data','Predicting Data')
%title('Prediction for training data')

%subplot(3,1,2);
%plot([1:400], [Y1(1:200,:)',Y1(1:200,:)'],'b');
%hold on
%plot([201:400], Y1xg_predict(1:200,:),'r');

%subplot(3,1,3);
%plot([1:400], [Y1(1:200,:)',Y1(1:200,:)'],'b');
%hold on
%plot([201:400], Y1yg_predict(1:200,:),'r');

% ———— Testing data ————
figure;
subplot(3,1,1);
plot([1:400], [Y1(1:200,:)',Y1_test'],'b');
hold on
plot([201:400], Y_predict,'r');
legend('Actual data','Predicting Data')
title('Prediction for testing data')

subplot(3,1,2);
plot([1:400], [Y1(1:200,:)',Y1_test'],'b');
hold on
plot([201:400], Yxg_predict,'r');

subplot(3,1,3);
plot([1:400], [Y1(1:200,:)',Y1_test'],'b');
hold on
plot([201:400], Yyg_predict,'r');

toc

%% ———— DArLVR training ————
[R, Q, Alpha, P, W, C, Gama, Lambda, ksi, M_T2, M_Q, M_phi, ...,
   RBC_T2_lim, RBC_Q_lim, RBC_phi_lim] = darlvr_rbc_train(X1,Y1,X1_test,Y1_test,a,gamma_w,gamma_beta,gamma_delta,s,d,f);

%% ———— DArLVR testing ————
% ———— Obtain the indices for the testing data ————
[RBC_T2_test, RBC_Q_test, RBC_phi_test] = darlvr_rbc_test(X1_test,Y1_test,...,
    a,gamma_w,gamma_beta,gamma_delta,s,d,R,Q,Alpha,P,W,C,Gama,Lambda, ksi, M_T2, M_Q, M_phi);

% ———— Obtain the indices for the training data ————
[RBC_T2_train, RBC_Q_train, RBC_phi_train] = darlvr_rbc_test(X1,Y1,...,
    a,gamma_w,gamma_beta,gamma_delta,s,d,R,Q,Alpha,P,W,C,Gama,Lambda, ksi, M_T2, M_Q, M_phi);

% ———— T2 & Q ————
N = n_test - g;
nt = 200 + N;

figure;
    subplot(3,1,1);
    plot([1:nt], [RBC_T2_train(1:200), RBC_T2_test], [1:nt], RBC_T2_lim * ones(1,nt),'r--');
    title('T^2');
    legend('statistic','control limit')
    
    subplot(3,1,2);
    plot([1:nt], [RBC_Q_train(1:200), RBC_Q_test], [1:nt], RBC_Q_lim * ones(1,nt),'r--');
    title('Q');
    
    subplot(3,1,3);
    plot([1:nt], [RBC_phi_train(1:200), RBC_phi_test], [1:nt], RBC_phi_lim * ones(1,nt),'r--');
    title('\phi_{dx}');



%% —————— PCA-based monitoring on X & Y——————
% ———— PCA Training ————
[lx_pca,ly_pca,Px_pca,Py_pca,lambda_x_pca,lambda_y_pca,Tx2_lim_pca,Ty2_lim_pca,Qx_lim_pca,Qy_lim_pca] = PCA_train(X1,Y1);

% ———— PCA Testing ————
% —— Obtain the indices for the testing data ——
[Tx2_index_pca_test,Ty2_index_pca_test,Qx_index_pca_test,Qy_index_pca_test] = PCA_test(X1_test,Y1_test,Px_pca,Py_pca,lambda_x_pca,lambda_y_pca);

% —— Obtain the indices for the training data ——
[Tx2_index_pca,Ty2_index_pca,Qx_index_pca,Qy_index_pca] = PCA_test(X1,Y1,Px_pca,Py_pca,lambda_x_pca,lambda_y_pca);

% ———— PCA: T2 & Q ————
figure;
subplot(4,1,1);
plot([1:400], [Ty2_index_pca(1:200), Ty2_index_pca_test], [1:400], Ty2_lim_pca * ones(1,400),'r--');
title('T_y^2');
legend('statistic','control limit')

subplot(4,1,2);
plot([1:400], [Tx2_index_pca(1:200), Tx2_index_pca_test], [1:400], Tx2_lim_pca * ones(1,400),'r--');
title('T_x^2');

subplot(4,1,3);
plot([1:400], [Qx_index_pca(1:200), Qx_index_pca_test], [1:400], Qx_lim_pca * ones(1,400),'r--');
title('Q_x');

subplot(4,1,4);
plot([1:400], [Qy_index_pca(1:200), Qy_index_pca_test], [1:400], Qy_lim_pca * ones(1,400),'r--');
title('Q_y');