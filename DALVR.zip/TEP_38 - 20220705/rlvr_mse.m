%% ———— Calculate the MSE of rLVR prediction ————
function mse=rlvr_mse(X0,Y0,X_test,Y_test,a,k)
Y_predict=rlvr_predict(X0,Y0,X_test,a,k);
Y_error=Y_test-Y_predict;
mse=sum(sum(Y_error.^2))/size(Y_predict,1);