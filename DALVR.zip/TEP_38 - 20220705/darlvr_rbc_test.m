function [T2, Q, phi] = darlvr_rbc_test(U1_test,Y1_test,...,
    a,gamma_w,gamma_beta,gamma_delta,s,d,R,Q,Alpha,P,W,C,Gama,Lambda, ksi, M_T2, M_Q, M_phi)

[n,m] = size(U1_test); np = size(Y1_test,2);
g = max(s,d); N = n - g; 

U_beta = zeros(N, m);
for l=1:a
    for i = 0:s
        U_beta = U_beta + Alpha(i+1,a) * U1_test(g-i+1:g-i+N,:);
    end
end

T2 = zeros(1,n); Q = zeros(1,n); phi = zeros(1,n); 
for k = 1:n
    for k = 1:s
        u = U1_test(k,:)';
        T2(k) = u'* M_T2 * u;
        Q(k) = u'* M_Q * u;
        phi(k) = u'* M_phi * u;
    end
    for k = 1:N
        T2(k+s) = u'* M_T2 * u;
        Q(k+s) = u'* M_Q * u;
        phi(k+s) = u'* M_phi * u;
    end
end