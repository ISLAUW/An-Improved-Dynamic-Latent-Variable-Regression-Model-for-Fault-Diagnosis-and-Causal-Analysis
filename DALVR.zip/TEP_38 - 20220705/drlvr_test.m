function [T2_index,Q_index] = drlvr_test(X1_test,Y1_test,a,s,kappa,R,B1,Q,A,P,W,C,Lambda,T2_lim,Q_lim)

n = size(X1_test,1);

for k = 1:n
    xk = X1_test(k,:)';    
    tc = R'*xk;
    T2_index(k) = tc'*inv(Lambda)*tc;
    xc = (eye(size(P*R')) - P*R')*xk;
    Q_index(k) = xc'*xc;    
end
end
