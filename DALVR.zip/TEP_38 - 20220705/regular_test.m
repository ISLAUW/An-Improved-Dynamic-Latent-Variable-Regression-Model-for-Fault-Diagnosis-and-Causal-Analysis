function [dim_count, phi_index] = regular_test(U1_test, U1, Af, M_phi, phi_lim, f, a, R, P, Alpha)

n = size(U1_test,1); 

dim_count = 0;

Ur = U1_test - (U1_test * R) * P';
[Uf Df Vf] = svd(Ur');

%% ———— Control limits for detection ————
for k = 1:n
    u = U1_test(k,:)'; 
    for i = 1:Af
        u = u - Uf * f;
    end
    
    % ———— phi ————
    phi_index(k) = u'* M_phi * u;
    if phi_index(k) > phi_lim
        dim_count = dim_count + 1;
    end 
    
end

end