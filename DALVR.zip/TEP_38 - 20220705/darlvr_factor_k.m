function [a,gamma_w,gamma_beta,gamma_delta,s,d] = darlvr_factor(X1,Y1)
% choose the number of DALVR factors by cross validation (a,kappa,s,d)
% a -- the number of latent variables
% kappa -- the parameter of regularization term
% s -- lags
% call functions: drlvr_mse,drlvr_predict,dlvr  

data = [X1,Y1];
[n,m] = size(X1); p = size(Y1,2);
gamma_w = 0.005; gamma_beta = 0.005; gamma_delta = 0.005;

k = 5;
%c = cvpartition(n,'KFold',k);

data_classification = cvpartition(n,'KFold',k); % Nonstratified partition
%idxTrain = training(data_classification);
%Train_Data = data(idxTrain,:);
%idxTest = test(data_classification);
%Test_Data = data(idxTest,:);

%Train_data = training(data_classification);
%Test_data = test(data_classification);

mses = zeros(k,1);

for a = 1:5
    for s = 1:5
        for d = 1:5
            
            for i = 1:k
                idxTrain = training(data_classification,k);
                train_data = data(idxTrain,:);
                idxTest = test(data_classification,k);
                test_data = data(idxTest,:);
                x_train = train_data(:,1:m);
                x_test = test_data(:,1:m);
                y_train = train_data(:,m+1:end);
                y_test = test_data(:,m+1:end);
                mses(i) = darlvr_mse(x_train,y_train,x_test,y_test,a,gamma_w,gamma_beta,gamma_delta,s,d);
            end
            
            mse(a,s,d) = mean(mses);              
            
        end
    end
end

sub = zeros(1,3);
for a = 1:5
    for s = 1:5
        for d = 1:5
            if mse(a,s,d) == min(min(min(mse)))
                sub = [a s d]; % 存放a的最大值的3个下标
            end
        end
    end
end

a = sub(1,1);
s = sub(1,2);
d = sub(1,3);