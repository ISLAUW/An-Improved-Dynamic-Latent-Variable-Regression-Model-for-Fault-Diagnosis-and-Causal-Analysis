function [T2_index,Q_index] = rlvr_test(x_test, y_test,r,t,p,q,lamda, T2_lim,Q_lim)

n = size(x_test,1);

for i = 1:n
    tc=r'*x_test(i,:)';
    xc=x_test(i,:)';
    %T2_index(i)=tc'*pinv(lamda)*tc;
    T2_index(i)=(n-1)*tc'*tc;
    x_k=(eye(size(p*r'))-p*r')*xc; Q_index(i)=x_k'*x_k;
    % Q_index(i)=xc'*(eye(size(p*r'))-p*r')*xc;
end
