function [Cont_T2, Cont_Q, Cont_phi, Cont_T2_lim, Cont_Q_lim, Cont_phi_lim] = darlvr_cont(U1, Y1, U1_test, Y1_test, a, s, d, P, W, Alpha)

% This function is used for contribution plots.

% U1 -- autoscaled input matrix of training data
% Y1 -- autoscaled output matrix of training data
% U1_test -- autoscaled input matrix of testing data
% a -- the number of principal components determined by cross-validation
% s -- the lag parameter to denote the degree of cross-correlations
% d -- the lag parameter to denote the degree of auto-correlations

[n,m] = size(U1); np = size(Y1,2);
n_test = size(U1_test,1);
g = max(s,d); N = n - g; Nt = n_test - g;

R = W * inv(P'*W);
T = U1* R;
Lambda = 1/(n-1) * T'* T;

%% ———— Contribution Plots ————
alpha = 0.01; level = 1 - alpha;

% ———— M_T2 ————
M_T2 = R * pinv(Lambda) * R'; % T2

% ———— M_Q ————
%M_Q = (eye(size(P*R'))-P*R') * (eye(size(P*R'))-P*R')'; % SPE
M_Q = eye(size(P*R'))-P*R';

% ———— M_phi ————
% —— T2_lim ——
T2_lim = chi2inv(level,a);
% —— Q_lim ——
U_beta = zeros(N,m);
for l = 1:a
    for i = 0:s
        U_beta = U_beta + Alpha(i+1,l) * U1(g-i+1:g-i+N,:);
    end
end

for k = 1:N
    u = U_beta(k,:)';
    Q_index(k) = u'* M_Q * u;
end
a_q = mean(Q_index); b_q = var(Q_index); 
g_q = b_q/(2*a_q); h_q = 2*a_q^2/b_q;
Q_lim = g_q * chi2inv(level,h_q);
% —— M_phi ——
M_phi = M_T2/T2_lim + M_Q/Q_lim; % phi

% ———— Contributions ————
Ut_beta = zeros(Nt,m);
for l = 1:a
    for i = 0:s
        Ut_beta = Ut_beta + Alpha(i+1,l) * U1_test(g-i+1:g-i+Nt,:);
    end
end

% ———— ksi ————
ksi = zeros (m,m);
for i = 1:m
    ksi(i,i) = 1;
end

% ———— Control Limit ————
Cont0_T2 = zeros(n,m); Cont0_Q = zeros(n,m); Cont0_phi = zeros(n,m); 
for i = 1:m
    
    ksi_i = ksi(i,:)';
    for k= 1:g
        u = U1(k,:)';       
        Cont0_T2(k,i) = real(u'* (M_T2)^0.5'* ksi_i * ksi_i'* (M_T2)^0.5 * u);
        Cont0_Q(k,i) = real(u'* (M_Q)^0.5' * ksi_i * ksi_i'* (M_Q)^0.5 * u);
        Cont0_phi(k,i) = real(u'* (M_phi)^0.5'* ksi_i * ksi_i'* (M_phi)^0.5 * u);
        
        %Cont_T2(k,i) = real((ksi_i'* (M_T2)^0.5 * u)^2);
        %Cont_Q(k,i) = real((ksi_i'* (M_Q)^0.5 * u)^2);
        %Cont_phi(k,i) = real((ksi_i'* (M_phi)^0.5 * u)^2);
        
    end      
    for k = 1:N
        %u = U_beta(k,:)';
        u = U1(k+g,:)';    
        Cont0_T2(k+g,i) = real(u'* (M_T2)^0.5'* ksi_i * ksi_i'* (M_T2)^0.5 * u);
        Cont0_Q(k+g,i) = real(u'* (M_Q)^0.5' * ksi_i * ksi_i'* (M_Q)^0.5 * u);
        Cont0_phi(k+g,i) = real(u'* (M_phi)^0.5'* ksi_i * ksi_i'* (M_phi)^0.5 * u);
        
        %Cont_T2(k,i) = real((ksi_i'* (M_T2)^0.5 * u)^2);
        %Cont_Q(k,i) = real((ksi_i'* (M_Q)^0.5 * u)^2);
        %Cont_phi(k,i) = real((ksi_i'* (M_phi)^0.5 * u)^2);
    end
            
    mu_T2(i) = mean(Cont0_T2(:,i)); std_T2(i) = std(Cont0_T2(:,i));
    mu_Q(i) = mean(Cont0_Q(:,i)); std_Q(i) = std(Cont0_Q(:,i));
    mu_phi(i) = mean(Cont0_phi(:,i)); std_phi(i) = std(Cont0_phi(:,i));
    
    Cont_T2_lim(i) = abs(mu_T2(i) + 2.3263 * std_T2(i));
    Cont_Q_lim(i) = abs(mu_Q(i) + 2.3263 * std_Q(i));
    Cont_phi_lim(i) = abs(mu_phi(i) + 2.3263 * std_phi(i));
    
end


Cont_T2 = zeros(n_test,m); Cont_Q = zeros(n_test,m); Cont_phi = zeros(n_test,m); 
for i = 1:m
    
    ksi_i = ksi(i,:)';
    for k= 1:g
        u = U1_test(k,:)';       
        Cont_T2(k,i) = real(u'* (M_T2)^0.5'* ksi_i * ksi_i'* (M_T2)^0.5 * u);
        Cont_Q(k,i) = real(u'* (M_Q)^0.5' * ksi_i * ksi_i'* (M_Q)^0.5 * u);
        Cont_phi(k,i) = real(u'* (M_phi)^0.5'* ksi_i * ksi_i'* (M_phi)^0.5 * u);
        
        %Cont_T2(k,i) = real((ksi_i'* (M_T2)^0.5 * u)^2);
        %Cont_Q(k,i) = real((ksi_i'* (M_Q)^0.5 * u)^2);
        %Cont_phi(k,i) = real((ksi_i'* (M_phi)^0.5 * u)^2);
        
    end      
    for k = 1:Nt
        %u = Ut_beta(k,:)';
        u = U1_test(k+g,:)';    
        Cont_T2(k+g,i) = real(u'* (M_T2)^0.5'* ksi_i * ksi_i'* (M_T2)^0.5 * u);
        Cont_Q(k+g,i) = real(u'* (M_Q)^0.5' * ksi_i * ksi_i'* (M_Q)^0.5 * u);
        Cont_phi(k+g,i) = real(u'* (M_phi)^0.5'* ksi_i * ksi_i'* (M_phi)^0.5 * u);
        
        %Cont_T2(k,i) = real((ksi_i'* (M_T2)^0.5 * u)^2);
        %Cont_Q(k,i) = real((ksi_i'* (M_Q)^0.5 * u)^2);
        %Cont_phi(k,i) = real((ksi_i'* (M_phi)^0.5 * u)^2);
    end
        
    %mu_T2(i) = mean(Cont_T2(:,i)); std_T2(i) = std(Cont_T2(:,i));
    %mu_Q(i) = mean(Cont_Q(:,i)); std_Q(i) = std(Cont_Q(:,i));
    %mu_phi(i) = mean(Cont_phi(:,i)); std_phi(i) = std(Cont_phi(:,i));
    
    %Cont_T2_lim(i) = abs(mu_T2(i) + 2.3263 * std_T2(i));
    %Cont_Q_lim(i) = abs(mu_Q(i) + 2.3263 * std_Q(i));
    %Cont_phi_lim(i) = abs(mu_phi(i) + 2.3263 * std_phi(i));
    
end
