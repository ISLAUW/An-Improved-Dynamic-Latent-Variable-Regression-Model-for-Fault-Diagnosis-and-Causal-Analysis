function Y_predict=drlvr_predict(X1,Y1,X1_test,Y1_test,a,s,kappa)
% X1 -- autoscaled input matrix of training data
% Y1 -- autoscaled output matrix of training data
% X1_test -- autoscaled input matrix of testing data
% a -- the number of principal components determined by cross-validation
% s -- the lag parameter to denote the degree of dynamics
% kappa -- the parameter of regularization term

[B1,Q,A,P,W,C]=drlvr(X1,Y1,a,s,kappa);
R=W*inv(P'*W);
Y_predict=zeros(size(Y1_test,1),size(Y1_test,2));
% Y_predict(1:s,:)=X1_test(1:s,:)*R*C';
N=size(X1_test,1)-s; 

Ts=zeros(N,s+1); 
T=X1_test*R; 
for l=1:a
    for i=1:size(X1_test,1)
        for j=0:s        
            Ts(:,j+1)=T(s-j+1:s-j+N,l);
        end       
    end
    us_hat = Ts*A(:,l); 
    Us_hat(:,l) = us_hat;
end

Y_predict(s+1:end,:) = Us_hat*C';