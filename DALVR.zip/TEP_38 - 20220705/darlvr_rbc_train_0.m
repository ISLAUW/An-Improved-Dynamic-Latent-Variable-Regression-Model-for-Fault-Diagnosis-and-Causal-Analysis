function [R,Q,Alpha,P,W,C,Gama,Lambda, ksi, Af, M_T2, M_Q, M_phi, ...,
   RBC_T2_lim, RBC_Q_lim, RBC_phi_lim] = darlvr_rbc_train(U1,Y1,U1_test, Y1_test, a,gamma_w,gamma_beta,gamma_delta,s,d,f)

% this function trains DArLVR
% U1 -- autoscaled input matrix of training data
% Y1 -- autoscaled output matrix of training data
% U1_test -- autoscaled input matrix of testing data
% a -- the number of principal components determined by cross-validation
% s -- the lag parameter to denote the degree of cross-correlations
% d -- the lag parameter to denote the degree of auto-correlations

[n,m] = size(U1); np = size(Y1,2);
g = max(s,d); N = n - g;

%% ———— DALVR ————
[P,Q,C,W,Alpha,Gama] = darlvr(U1,Y1,a,gamma_w,gamma_beta,gamma_delta,s,d);
R = W * pinv(P'*W);
T = U1*R;
Lambda = 1/n * T'*T;

%% ———— Reconstruction-Based Contribution (RBC) ————
alpha = 0.01; level = 1 - alpha;

M_T2 = R * inv(Lambda) * R'; % T2
M_Q = (eye(size(P*R'))-P*R'); % SPE

% ———— Control Limits ————
T2_lim = chi2inv(level,a); 

U_beta = zeros(N, m);
for l = 1:a
    for i = 0:s
        U_beta = U_beta + Alpha(i+1,l) * U1(g-i+1:g-i+N,:);
    end
end

for k = 1:N
    u = U_beta(k,:)';
    Q_index(k) = u'* M_Q * u;
end
a_q = mean(Q_index); b_q = var(Q_index); 
g_q = b_q/(2*a_q); h_q = 2*a_q^2/b_q;
Q_lim = g_q * chi2inv(level,h_q);

M_phi = M_T2/T2_lim + M_Q/Q_lim; % phi

S = 1/(n-1)* U1'* U1;
g_phi = trace((S * M_phi)^2)/trace(S * M_phi);
h_phi = (trace(S * M_phi))^2/trace((S * M_phi)^2);
phi_lim = g_phi * chi2inv(level,h_phi);

%ksi

%Af = 1; Af_num = 0;

%dim_count = regular_test(U1_test, Uf, Af, M_phi, phi_lim, f);
%for i = 1:m 
    %if dim_count < n * alpha        
        %Af_num = Af_num + 1;
    %end
%end


%Ur = U1_test - (U1_test * R) * P';
%Ur = U1 - T * P';

[Uf Df Vf] = svd(U1_test');
Af = pc_number(U1_test);
ksi = Uf;
cont_j_phi = (ksi_i)^2;

%h_rt2 = 1; h_rq = 1; h_rp = 1;
%for i = 1:m
    %g_rt2(i) = ksi(:,i)'* M_T2 * S * M_T2 * ksi(:,i);    
    %RBC_T2_lim(i) = g_rt2(i) * chi2inv(level,h_rt2);
    %g_rq(i) = ksi(:,i)'* M_Q * S * M_Q * ksi(:,i);    
    %RBC_Q_lim(i) = g_rq(i) * chi2inv(level,h_rq);
    %g_rp(i) = ksi(:,i)'* M_phi * S * M_phi * ksi(:,i); 
    %RBC_phi_lim(i) = g_rp(i) * chi2inv(level,h_rp);
%end

for i = 1:Af
    ksi_i = ksi(:,i);
    g_rt2(i) = trace((S * M_T2 * ksi_i * pinv(ksi_i'* M_T2 * ksi_i) * ksi_i' * M_T2)^2) / trace(S * M_T2 * ksi_i * pinv(ksi_i'* M_T2 * ksi_i) * ksi_i' * M_T2);
    h_rt2(i) = (trace(S * M_T2 * ksi_i * pinv(ksi_i'* M_T2 * ksi_i) * ksi_i' * M_T2))^2 / trace((S * M_T2 * ksi_i * pinv(ksi_i'* M_T2 * ksi_i) * ksi_i' * M_T2)^2);
    RBC_T2_lim(i) = abs(g_rt2(i) * chi2inv(level,h_rt2(i)));
    
    g_rq(i) = trace((S * M_Q * ksi_i * pinv(ksi_i'* M_Q * ksi_i) * ksi_i' * M_Q)^2) / trace(S * M_Q * ksi_i * pinv(ksi_i'* M_Q * ksi_i) * ksi_i' * M_Q);
    h_rq(i) = (trace(S * M_Q * ksi_i * pinv(ksi_i'* M_Q * ksi_i) * ksi_i' * M_Q))^2 / trace((S * M_Q * ksi_i * pinv(ksi_i'* M_Q * ksi_i) * ksi_i' * M_Q)^2);    
    RBC_Q_lim(i) = g_rq(i) * chi2inv(level,h_rq(i));
    
    g_rp(i) = trace((S * M_phi * ksi_i * pinv(ksi_i'* M_phi * ksi_i) * ksi_i' * M_phi)^2) / trace(S * M_phi * ksi_i * pinv(ksi_i'* M_phi * ksi_i) * ksi_i' * M_phi);
    h_rp(i) = (trace(S * M_phi * ksi_i * pinv(ksi_i'* M_phi * ksi_i) * ksi_i' * M_phi))^2 / trace((S * M_phi * ksi_i * pinv(ksi_i'* M_phi * ksi_i) * ksi_i' * M_phi)^2);
    RBC_phi_lim(i) = abs(g_rp(i) * chi2inv(level,h_rp(i)));
end
