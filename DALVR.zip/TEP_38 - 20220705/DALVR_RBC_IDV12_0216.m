clear all
clc
close all
format short;
tic

%% ———— Data ————
% ———— Training Data: IDV(0) ————
%load d00.dat;
% —— Training Data ——
%T = 1; 
%n = size(d00,2)/T;

%X0 = zeros(n,33); Y0 = zeros(n,1); 
%for i = 1:n
    %X0(i,:) = [d00(1:22,(T*i))',d00(42:52,(T*i))']; 
    %Y0(i,:) = d00(35,(T*i))';
%end

%X0 = X0(1:480,:); Y0 = Y0(1:480,:);

% ———— Training Data: IDV(0) ————
load d00_te.dat;
% —— Training Data ——
T0 = 2; 
n = size(d00_te,1)/T0;
X0 = zeros(n,33); Y0 = zeros(n,1); 

for j = 1:n
    X0(j,:) = [d00_te((T0*j-1),1:22),d00_te((T0*j-1),42:52)]; 
    Y0(j,:) = d00_te((T0*j-1),35);    
end

X0 = X0(1:480,:); Y0 = Y0(1:480,:);

% ———— Testing Data: IDV(12) ————
load d12_te.dat; % 960*52
X0_te = d12_te;

T = 2;
% —— Testing Data Downsampled ——
n_te = size(X0_te,1)/T;
X0_test = zeros(n_te,33); Y0_test=zeros(n_te,1); 
for j = 1:n_te
    X0_test(j,:) = [X0_te((T*j-1),1:22),X0_te((T*j-1),42:52)]; 
    Y0_test(j,:) = X0_te((T*j-1),35);    
end

% ———— Autoscale the training data and testing data ————
[X1,mx_train,vx_train] = autos(X0);
[Y1,my_train,vy_train] = autos(Y0);

X1_test = autos_test(X0_test,mx_train,vx_train);
Y1_test = autos_test(Y0_test,my_train,vy_train);

[n_train,m] = size(X1);
n_test = size(X1_test,1);

%% ———— Parameter Determination————
load darlvr_factor_data.mat
%a = 2; s = 2; d = 2;
gamma_w = 0.005; gamma_beta = 0.005; gamma_delta = 0.005;

%% ———— DALVR ————
g = max(s,d); 
[P,Q,C,W,Beta,Delta] = darlvr(X1,Y1,a,gamma_w,gamma_beta,gamma_delta,s,d);

%% ———— Monitoring ————
% ———— Testing Data ————
[T2_index_test, Q_index_test, phi_index_test, T2_lim, Q_lim, phi_lim] ...
    = darlvr_monitoring (X1, Y1, X1_test, Y1_test, a, s, d, P, Q, C, W, Beta, Delta);

% ———— Training Data ————
[T2_index_train, Q_index_train, phi_index_train] ...
    = darlvr_monitoring (X1, Y1, X1, Y1, a, s, d, P, Q, C, W, Beta, Delta);

%% ———— Reconstruction-Based Contribution ————
[R,Q,Alpha,P,W,C,Gama,Lambda, ksi, RBC_T2_test, RBC_Q_test, RBC_phi_test, RBC_T2_rate, RBC_Q_rate, RBC_phi_rate,RBC_index_T2, RBC_index_Q, RBC_index_phi, ...
   RBC_T2_lim, RBC_Q_lim, RBC_phi_lim] = darlvr_rbc(X1,Y1,X1_test, Y1_test, a,gamma_w,gamma_beta,gamma_delta,s,d);

[~,~,~,~,~,~,~,~,~,RBC_T2_train, RBC_Q_train, RBC_phi_train,~,~,~,~,~,~, ...
   ~,~,~] = darlvr_rbc(X1,Y1,X1,Y1,a,gamma_w,gamma_beta,gamma_delta,s,d);

%% ———— Contribution Plots ————
[Cont_T2_test, Cont_Q_test, Cont_phi_test, Cont_T2_lim, Cont_Q_lim, Cont_phi_lim] = darlvr_cont(X1, Y1, X1_test, Y1_test, a, s, d, P, W, Beta);


%% ———— Plotting ————
% ———— Monitoring ————
n_plot = n_test;

figure
subplot(3,1,1)
plot([1:n_plot], [T2_index_test], [1:n_plot], T2_lim * ones(1,n_plot));
title('T^2');
legend('Statistic', 'Control Limit')

subplot(3,1,2)
plot([1:n_plot], [Q_index_test], [1:n_plot], Q_lim * ones(1,n_plot));
title('Q');

subplot(3,1,3)
plot([1:n_plot], [phi_index_test], [1:n_plot], phi_lim * ones(1,n_plot));
title('\phi');

% Combined Index
figure
plot([1:n_plot], [phi_index_test], [1:n_plot], phi_lim * ones(1,n_plot));
title('\phi');
legend('Statistic', 'Control Limit')

% ———— Combined RBC Index Based on 1 as Control Limit ————
for i = 1:m
    RBC_phi_avg(i) = 1/length(RBC_phi_train) * sum(RBC_phi_train(:,i));
    RBC_phi_relative_test(:,i) = RBC_phi_test(:,i) / RBC_phi_avg(i);    
end

figure
subplot(6,1,1)
bar(RBC_phi_relative_test(75,:))
hold on
plot([1:m], 1 * ones(1,size(RBC_phi_test,2)))
title('75^{th}')
legend('RBC','Control limit')
%ylim([0 1.5])

subplot(6,1,2)
bar(RBC_phi_relative_test(76,:))
hold on
plot([1:m], 1 * ones(1,size(RBC_phi_test,2)))
title('76^{th}')
%ylim([0 1.5])

subplot(6,1,3)
bar(RBC_phi_relative_test(81,:))
hold on
plot([1:m], 1 * ones(1,size(RBC_phi_test,2)))
title('81^{st}')
%ylim([0 15])

subplot(6,1,4)
bar(RBC_phi_relative_test(82,:))
hold on
plot([1:m], 1 * ones(1,size(RBC_phi_test,2)))
title('82^{nd}')
%ylim([0 15])

subplot(6,1,5)
bar(RBC_phi_relative_test(120,:))
hold on
plot([1:m], 1 * ones(1,size(RBC_phi_test,2)))
title('120^{th}')
%ylim([0 280])

subplot(6,1,6)
bar(RBC_phi_relative_test(292,:))
hold on
plot([1:m], 1 * ones(1,size(RBC_phi_test,2)))
title('292^{th}')
%ylim([0 280])


% ———— Combined RBC Index Based on Average Normal Training Samples ————
%RBC_phi_avg_train = 1/length(RBC_phi_train) * sum(RBC_phi_train);

%figure
%subplot(4,1,1)
%bar(RBC_phi_test(140,:))
%hold on
%plot([1:m],RBC_phi_avg_train)
%title('140^{th}')
%legend('RBC','Normal Average')

%subplot(4,1,2)
%bar(RBC_phi_test(167,:))
%hold on
%plot([1:m],RBC_phi_avg_train)
%title('167^{th}')

%subplot(4,1,3)
%bar(RBC_phi_test(180,:))
%hold on
%plot([1:m],RBC_phi_avg_train)
%title('180^{th}')

%subplot(4,1,4)
%bar(RBC_phi_test(400,:))
%hold on
%plot([1:m],RBC_phi_avg_train)
%title('400^{th}')

% ———— Combined RBC Index Based on Average Normal Testing Samples ————
%RBC_phi_avg_te = 0;
%for i = 1:166
%    RBC_phi_avg_te = RBC_phi_avg_te + RBC_phi_test(i,:);    
%end
%RBC_phi_avg_test = 1/166 * RBC_phi_avg_te;

%figure
%subplot(4,1,1)
%bar(RBC_phi_test(140,:))
%hold on
%plot([1:m],RBC_phi_avg_test)
%title('140^{th}')
%legend('RBC','Normal Average')

%subplot(4,1,2)
%bar(RBC_phi_test(167,:))
%hold on
%plot([1:m],RBC_phi_avg_test)
%title('167^{th}')

%subplot(4,1,3)
%bar(RBC_phi_test(180,:))
%hold on
%plot([1:m],RBC_phi_avg_test)
%title('180^{th}')

%subplot(4,1,4)
%bar(RBC_phi_test(400,:))
%hold on
%plot([1:m],RBC_phi_avg_test)
%title('400^{th}')

% ———— Combined RBC Index Based on Control Limit ————
%figure
%subplot(5,1,1)
%bar(RBC_phi_avg_test)
%hold on
%plot([1:m],RBC_phi_lim)
%title('average')
%legend('RBC','Control limit')

%subplot(5,1,2)
%bar(RBC_phi_test(140,:))
%hold on
%plot([1:m],RBC_phi_lim)
%title('140^{th}')

%subplot(5,1,3)
%bar(RBC_phi_test(167,:))
%hold on
%plot([1:m],RBC_phi_lim)
%title('167^{th}')

%subplot(5,1,4)
%bar(RBC_phi_test(180,:))
%hold on
%plot([1:m],RBC_phi_lim)
%title('180^{th}')

%subplot(5,1,5)
%bar(RBC_phi_test(400,:))
%hold on
%plot([1:m],RBC_phi_lim)
%title('400^{th}')

% ———— RBC Indices for a Specific Sample ————
%k = 165;

%figure
%subplot(3,1,1)
%bar(RBC_T2_test(k,:))
%hold on
%plot([1:m],RBC_T2_lim)
%title('RBC^{T^2}')
%legend('RBC','Control limit')

%subplot(3,1,2)
%bar(RBC_Q_test(k,:))
%hold on
%plot([1:m],RBC_Q_lim)
%title('RBC^{Q}')

%subplot(3,1,3)
%bar(RBC_phi_test(k,:))
%hold on
%plot([1:m],RBC_phi_lim)
%title('RBC^{\phi}')

% ———— Contribution Plots ————
% figure
% subplot(3,1,1)
%bar(Cont_T2_test(k,:))
%hold on
%plot([1:m],Cont_T2_lim)
%title('Cont^{T^2}')
%legend('Contribution plots','Control limit')

%subplot(3,1,2)
%bar(Cont_Q_test(k,:))
%hold on
%plot([1:m],Cont_Q_lim)
%title('Cont^{Q}')

%subplot(3,1,3)
%bar(Cont_phi_test(k,:))
%hold on
%plot([1:m],Cont_phi_lim)
%title('Cont^{\phi}')



% ———— Output ————
figure
plot(Y1_test,'b');
title('Output')
%legend('predicting data','test data')

%% ———— Causality ————
alpha = 0.01; max_lag = 10;

% k = 292;
k = 344;

RBC_variables = zeros(0,0);
for i = 1:m
    if RBC_phi_relative_test(k,i) > (1/3 * max(RBC_phi_relative_test(k,:)) )
        RBC_variables = [RBC_variables i];
    end
end

%T = 2;
%n_te = size(X1_test,1)/T;
% ———— Data Sampling ————
%X0_tesa = zeros(n_te,33); Y0_tesa = zeros(n_te,1); 
%for j = 1:n_te
%    X0_tesa(j,:) = X0_test((T*j-1),:); 
%    Y0_tesa(j,:) = Y0_test((T*j-1),:);    
%end

%X1_tesa = zeros(n_te,33); Y1_tesa = zeros(n_te,1); 
%for j = 1:n_te
%    X1_tesa(j,:) = X1_test((T*j-1),:); 
%    Y1_tesa(j,:) = Y1_test((T*j-1),:); 
%end

%X0_te_cause = zeros(n_te, length(RBC_variables));
X1_te_cause = zeros(n_te, length(RBC_variables));
for i = 1:length(RBC_variables)
%    X0_te_cause(:,i) = X0_tesa(:,RBC_variables(i));
    X1_te_cause(:,i) = X1_test(:,RBC_variables(i));
end



%[variable_osi, no_cause_xy] = Granger_Causality_sample (X1_te_cause, Y1_test, k, alpha, max_lag, a, gamma_w, gamma_beta, gamma_delta, s, d);

%[variable_osi, no_cause_xy] = Granger_Causality_sample (X1_te_cause, Y1_test, 178, alpha, max_lag, a, gamma_w, gamma_beta, gamma_delta, s, d);


%[variable_osi, no_cause_xy] = Granger_Causality_all (X1_test, Y1_test, alpha, max_lag, a, gamma_w, gamma_beta, gamma_delta, s, d);
%[variable_osi, no_cause_xy] = Granger_Causality_all (X1_tesa, Y1_tesa, alpha, max_lag, a, gamma_w, gamma_beta, gamma_delta, s, d);

[C, no_cause_x1, no_cause_x2] = Granger_Causality_only (X1_te_cause, Y1_test, alpha, max_lag, a, gamma_w, gamma_beta, gamma_delta, s, d);

%[C, no_cause_x1, no_cause_x2] = Granger_Causality_all (X1_test, Y1_test, alpha, max_lag, a, gamma_w, gamma_beta, gamma_delta, s, d);
