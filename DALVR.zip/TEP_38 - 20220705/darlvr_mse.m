function [MSE_overall,MSE_Yxg,MSE_Yyg] = darlvr_mse(X1,Y1,X1_test,Y1_test,a,gamma_w,gamma_beta,gamma_delta,s,d)
% X1 -- autoscaled input matrix of training data
% Y1 -- autoscaled output matrix of training data
% X1_test -- autoscaled input matrix of testing data
% a -- the number of principal components determined by cross-validation
% s -- the lag parameter to denote the degree of dynamics
% kappa -- the parameter of regularization term

[Y_predict,Yxg_predict,Yyg_predict] = darlvr_predict(X1,Y1,X1_test,Y1_test,a,gamma_w,gamma_beta,gamma_delta,s,d);
[n,m] = size(X1_test); np = size(Y1_test,2);
g = max(s,d); N = n - g; 

Y_error = Y1_test(g+1:end,:) - Y_predict(g+1:end,:); 
MSE_overall = sum(sum(Y_error.^2)) / N; 
Yxg_error = Y1_test(g+1:end,:) - Yxg_predict(g+1:end,:) ; 
MSE_Yxg = sum(sum(Yxg_error.^2)) / N;
Yyg_error = Y1_test(g+1:end,:) - Yyg_predict(g+1:end,:); 
MSE_Yyg = sum(sum(Yyg_error.^2)) / N;