%% ———— PCA Testing————
function [Tx2_index,Ty2_index,Qx_index,Qy_index]=PCA_test(x_test,y_test,Tx,Ty,Px,Py,lamda_x,lamda_y)

n=size(x_test,1);

for i=1:n
    x=x_test(i,:)'; y=y_test(i,:)';
    tx=Px'*x; ty=Py'*y;
    Tx2_index(i)=tx'*pinv(lamda_x)*tx;
    Ty2_index(i)=ty'*pinv(lamda_y)*ty;
    xk=(eye(size(Px*Px'))-Px*Px')*x; Qx_index(i)=xk'*xk;
    yk=(eye(size(Py*Py'))-Py*Py')*y; Qy_index(i)=yk'*yk;
end
