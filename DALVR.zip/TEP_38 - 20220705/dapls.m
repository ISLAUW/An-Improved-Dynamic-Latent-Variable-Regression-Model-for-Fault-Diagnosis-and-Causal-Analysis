%% ———— DAPLS ————
function [P, Q, C, W, Beta, Sigma] = dapls(X0, Y0, a, s, d)

% U1 -- autoscaled input matrix of training data
% Y1 -- autoscaled output matrix of training data
% X1_test -- autoscaled input matrix of testing data
% a -- the number of principal components determined by cross-validation
% s -- the lag parameter to denote the degree of dynamics corresponding to input (t)
% d -- the lag parameter to denote the degree of dynamics corresponding to output (u)
% kappa -- the regularization term


% X_back = X0;
% Y_back = Y0;
g = max(s, d);
[n, m] = size(X0);
np = size(Y0, 2);
N = n - g; 

%% Step 1: Initialize beta and sigma, and u_s as some column of Y0
beta = rand(s+1, 1);
beta = beta / norm(beta);
sigma = rand(d, 1);
sigma = sigma / norm(sigma);

% beta = zeros(s+1, 1);
% beta(1,1) = 1;
% sigma = zeros(d, 1);
% sigma(1,1) = 1;

u = Y0(:, 1);
ug = u(g+1:N+g);

l = 0;
W = zeros(0, 0);
P = zeros(0, 0);
Q = zeros(0, 0);
C = zeros(0, 0);
Beta = zeros(0, 0);
Sigma = zeros(0, 0);
B = zeros(0);

while l < a
    %% Step 2: Outer modeling
    iter = 0;
    while true
        temp_beta = beta;
        % Form X_beta and Y_sigma
        X_beta = zeros(N, m);
        for i = 0:s
            X_beta = X_beta + beta(i+1) * X0(g-i+1:g-i+N, :);
        end
        Y_sigma = zeros(N, np);
        for i = 1:d
            Y_sigma = Y_sigma + sigma(i) * Y0(g-i+1:g-i+N, :);
        end
        Yg = Y0(g+1:N+g, :);
            
        w = X_beta' * ug;
        w = w / norm(w);
        
        t = X0*w;
        % From Ts and Ud
        Ts = zeros(N, s+1);
        for i = 0:s
            Ts(:, i+1) = t(s-i+1:s-i+N);
        end
        Ud = zeros(N, d);
        for i = 1:d
            Ud(:, i) = u(g-i+1:g-i+N);
        end
        
        q = Yg'*Ts*beta + Yg'*Ud*sigma + Y_sigma'*ug;
        q = q / norm(q);
        
        u = Y0*q;
        ug = Yg*q;  
        
        beta = Ts'*ug;
        beta = beta / norm(beta);
        
        sigma = Ud'*ug;
        sigma = sigma / norm(sigma);
        
        
        if norm(temp_beta - beta) < 0.000001 || norm(temp_beta + beta) < 0.000001
            break;
        end
        iter = iter + 1;
        if iter > 10000
            fprintf('---- DPLS 10000 Iterations ---a: %d, s: %d, d, %d\n', a, s, d);
            break;
        end
    end
    
%     J_q = q'*Yg'*Ts*beta + Yg'*Ud*sigma + Y_sigma'*ug;
%     J_w = w'*X_beta' * ug;
%     J_beta = beta'*Ts'*ug;
%     J_sigma = sigma'*Ud'*ug;
    
    %% Step 3: Inner modeling 
    % ARIMA
    z = [u, t];
    opt = arxOptions('InputOffset', 1);
    sys = arx(z,[d s+1 1], opt);
    beta_hat = sys.B;
    beta_hat = beta_hat(2:length(beta_hat))';
    sigma_hat = sys.A;
    sigma_hat = sigma_hat(2:length(sigma_hat))';
    
    ug_hat = Ts*beta_hat + Ud*sigma_hat;
    
    b = u(1:g)'*t(1:g) / (t(1:g)'*t(1:g));
    
    %% Step 4: Deflation - Deflate X and Y 
    p = X0'*t/(t'*t);
    c = Yg'*ug_hat/(ug_hat'*ug_hat);
    X0 = X0 - t*p';
    Y0(1:g, :) = Y0(1:g, :) - b*t(1:g)*q';
    Y0(g+1:n, :) = Y0(g+1:n, :) - ug_hat * c';
    
    
    
    
    
    
    
    
    l = l + 1;

    P = [P p];
    Q = [Q q];
    C = [C c];
    W = [W w];
    Beta = [Beta beta_hat];
    Sigma = [Sigma sigma_hat];
    B = [B b];
end
% auto_corr(Y_back)
% auto_corr(Y0)
% auto_corr(X0)

