function [T2_index, Q_index, phi_index, T2_lim, Q_lim, phi_lim] ...
    = darlvr_monitoring_2 (U1, Y1, U1_test, Y1_test, a, s, d, P, Q, C, W, Beta, Delta)

[n,m] = size(U1); np = size(Y1,2);
n_test = size(U1_test,1);
g = max(s,d); N = n - g; Nt = n_test - g;

R = W * pinv(P'*W);
T = U1*R;
Lambda = 1/(n-1) * T'*T;

%% ———— Control Limits ————
alpha = 0.01; level = 1 - alpha;

M_T2 = R * pinv(Lambda) * R'; % T2
M_Q = (eye(size(P*R'))-P*R'); % SPE

% ———— Control Limits ————
T2_lim = chi2inv(level,a);

U_beta = zeros(N,m);
for l = 1:a
    for i = 0:s
        U_beta = U_beta + Beta(i+1,l) * U1(g-i+1:g-i+N,:);
    end
end

for k = 1:N
    u = U_beta(k,:)';
    Q1_index(k) = u'* M_Q * u;
end
a_q = mean(Q1_index); b_q = var(Q1_index); 
g_q = b_q/(2*a_q); h_q = 2*a_q^2/b_q;
Q_lim = g_q * chi2inv(level,h_q);

M_phi = M_T2/T2_lim + M_Q/Q_lim; % phi

U_beta = zeros(N,m);
for l = 1:a
    for i = 0:s
        U_beta = U_beta + Beta(i+1,l) * U1(g-i+1:g-i+N,:);
    end
end

S = 1/(N-1)* U_beta'* U_beta;

g_phi = trace((S * M_phi)^2)/trace(S * M_phi);
h_phi = (trace(S * M_phi))^2/trace((S * M_phi)^2);
phi_lim = g_phi * chi2inv(level,h_phi);

%% ———— Process Monitoring ————
Ut_beta = zeros(Nt,m);
for l = 1:a
    for i = 0:s
        Ut_beta = Ut_beta + Beta(i+1,l) * U1_test(g-i+1:g-i+Nt,:);
    end
end

T2 = zeros(1,n_test); Q = zeros(1,n); phi = zeros(1,n); 
for k = 1:n
    for k = 1:g
        u = U1_test(k,:)';
        T2_index(k) = abs(u'* M_T2 * u);
        Q_index(k) = abs(u'* M_Q * u);
        phi_index(k) = abs(u'* M_phi * u);
    end
    for k = 1:Nt
        u = Ut_beta(k,:)';
        T2_index(k+g) = abs(u'* M_T2 * u);
        Q_index(k+g) = abs(u'* M_Q * u);
        phi_index(k+g) = abs(u'* M_phi * u);
    end
end
