function [a,k]=rlvr_factor(X0,Y0)
% choose the number of rLVR factors by cross validation
% call functions: rlvr_mse, rlvr_predict, rlvr   
m=size(X0,2);
for i=1:m
    for j=0.001:1.001:0.001
        fun=@(XTRAIN,YTRAIN,XTEST,YTEST)(rlvr_mse(XTRAIN,YTRAIN,XTEST,YTEST,i,j));
        vals=crossval(fun,X0,Y0);
        mse(i,j*1000)=mean(vals);
    end
end
z=min(mse); zz=min(z);
[a,k]=find(mse==zz);
%[row,column]=find(A==mm) %给出最小值mm在矩阵A中的行号row和列号column

