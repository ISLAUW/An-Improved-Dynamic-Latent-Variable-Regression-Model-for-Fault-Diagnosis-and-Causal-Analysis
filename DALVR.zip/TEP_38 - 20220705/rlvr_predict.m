function Y_predict=rlvr_predict(X0,Y0,X_test,a,k)
[~,P,~,W,C]=rlvr(X0,Y0,a,k);
R=W*pinv(P'*W);
Y_predict=X_test*R*C';


