clear all
clc
close all
format short;
tic

%% ———— Data ————
% ———— Training Data: Fault 2 ————
load Numerical_Simulation.mat
X0 = X_f0; Y0 = Y_f0; 
X0_test = X_f2; Y0_test = Y_f2;

% ———— Autoscale the training data and testing data ————
[X1,mx_train,vx_train] = autos(X0);
[Y1,my_train,vy_train] = autos(Y0);

X1_test = autos_test(X0_test,mx_train,vx_train);
Y1_test = autos_test(Y0_test,my_train,vy_train);

[n_train,m] = size(X1);
n_test = size(X1_test,1);

%% ———— Parameter Determination————
load darlvr_factor_data.mat
f = fault;
a = 2; s = 2; d = 2;

%% ———— DALVR ————
g = max(s,d); 
[P,Q,C,W,Beta,Delta,Y1_debug] = darlvr(X1,Y1,a,gamma_w,gamma_beta,gamma_delta,s,d);

% ———— RBC ————
[R,Q,Alpha,P,W,C,Gama,Lambda, ksi, RBC_T2_test, RBC_Q_test, RBC_phi_test, RBC_T2_rate, RBC_Q_rate, RBC_phi_rate, ...,
   RBC_T2_lim, RBC_Q_lim, RBC_phi_lim] = darlvr_rbc(X1,Y1,X1_test, Y1_test, a,gamma_w,gamma_beta,gamma_delta,s,d);

% ———— Monitoring ————
[R,Q,Alpha,P,W,C,Gama,Lambda,M_T2, M_Q, M_phi, ...,
   T2_lim, Q_lim, phi_lim] = darlvr_rbc_train(X1,Y1,X1_test, Y1_test, a,gamma_w,gamma_beta,gamma_delta,s,d);

[T2_index_test, Q_index_test, phi_index_test] = darlvr_rbc_test(X1_test,Y1_test,...,
    a,gamma_w,gamma_beta,gamma_delta,s,d,R,Q,Alpha,P,W,C,Gama,Lambda, ksi, M_T2, M_Q, M_phi);

[T2_index_train, Q_index_train, phi_index_train] = darlvr_rbc_test(X1,Y1,...,
    a,gamma_w,gamma_beta,gamma_delta,s,d,R,Q,Alpha,P,W,C,Gama,Lambda, ksi, M_T2, M_Q, M_phi);




%nt = 200 + n_test;
%for i = 1:m
%figure;
%subplot(3,1,1);
%plot([1:nt], [RBC_T2_train(1:200,i)', RBC_T2_test(:,i)'], [1:nt], RBC_T2_lim(i) * ones(1,nt),'r--');
%title('T^2');
%legend('statistic','control limit')
    
%subplot(3,1,2);
%plot([1:nt], [RBC_Q_train(1:200,i)', RBC_Q_test(:,i)'], [1:nt], RBC_Q_lim(i) * ones(1,nt),'r--');
%title('Q');
    
%subplot(3,1,3);
%plot([1:nt], [RBC_phi_train(1:200,i)', RBC_phi_test(:,i)'], [1:nt], RBC_phi_lim(i) * ones(1,nt),'r--');
%title('\phi_{dx}');
%end


%% —————— PCA-based monitoring on X & Y——————
% ———— PCA Training ————
[lx_pca,ly_pca,Px_pca,Py_pca,lambda_x_pca,lambda_y_pca,Tx2_lim_pca,Ty2_lim_pca,Qx_lim_pca,Qy_lim_pca] = PCA_train(X1,Y1);

% ———— PCA Testing ————
% —— Obtain the indices for the testing data ——
[Tx2_index_pca_test,Ty2_index_pca_test,Qx_index_pca_test,Qy_index_pca_test] = PCA_test(X1_test,Y1_test,Px_pca,Py_pca,lambda_x_pca,lambda_y_pca);

% —— Obtain the indices for the training data ——
[Tx2_index_pca,Ty2_index_pca,Qx_index_pca,Qy_index_pca] = PCA_test(X1,Y1,Px_pca,Py_pca,lambda_x_pca,lambda_y_pca);

% ———— PCA: T2 & Q ————
figure;
subplot(4,1,1);
plot([1:400], [Ty2_index_pca(1:200), Ty2_index_pca_test], [1:400], Ty2_lim_pca * ones(1,400),'r--');
title('T_y^2');
legend('statistic','control limit')

subplot(4,1,2);
plot([1:400], [Tx2_index_pca(1:200), Tx2_index_pca_test], [1:400], Tx2_lim_pca * ones(1,400),'r--');
title('T_x^2');

subplot(4,1,3);
plot([1:400], [Qx_index_pca(1:200), Qx_index_pca_test], [1:400], Qx_lim_pca * ones(1,400),'r--');
title('Q_x');

subplot(4,1,4);
plot([1:400], [Qy_index_pca(1:200), Qy_index_pca_test], [1:400], Qy_lim_pca * ones(1,400),'r--');
title('Q_y');



% ———— T2 ————
TP_T2 = zeros(size(X1_test,1),1);
TN_T2 = zeros(size(X1_test,1),1);
FP_T2 = zeros(size(X1_test,1),1);
FN_T2 = zeros(size(X1_test,1),1);

for count = 1:size(X1_test,1)
    if T2_index_test(count) > T2_lim && Ty2_index_pca_test(count) > Ty2_lim_pca
        TP_T2(count) = 1;
    elseif T2_index_test(count) < T2_lim && Ty2_index_pca_test(count) < Ty2_lim_pca
        TN_T2(count) = 1;
    elseif T2_index_test(count) > T2_lim && Ty2_index_pca_test(count) < Ty2_lim_pca
        FP_T2(count) = 1;
    elseif T2_index_test(count) < T2_lim && Ty2_index_pca_test(count) > Ty2_lim_pca
        FN_T2(count) = 1;
    end
end

if sum(TP_T2) == 0 && sum(FN_T2) == 0
    FDR_T2 = 0
    MAR_T2 = 0;
else
    FDR_T2 = sum(TP_T2) / (sum(TP_T2) + sum(FN_T2))
    MAR_T2 = sum(FN_T2) / (sum(TP_T2) + sum(FN_T2));
end

if sum(FP_T2) == 0 && sum(TN_T2) == 0
    FAR_T2 = 0
else
    FAR_T2 = sum(FP_T2) / (sum(FP_T2) + sum(TN_T2))
end

Detect_T2 = (sum(TP_T2) + sum(FN_T2))/(sum(TP_T2) + sum(FN_T2) + sum(FP_T2) + sum(TN_T2))

% ———— Q ————
TP_Q = zeros(size(X1_test,1),1);
TN_Q = zeros(size(X1_test,1),1);
FP_Q = zeros(size(X1_test,1),1);
FN_Q = zeros(size(X1_test,1),1);

for count = 1:size(X1_test,1)
    if Q_index_test(count) > Q_lim && Ty2_index_pca_test(count) > Ty2_lim_pca
        TP_Q(count) = 1;
    elseif Q_index_test(count) < Q_lim && Ty2_index_pca_test(count) < Ty2_lim_pca
        TN_Q(count) = 1;
    elseif Q_index_test(count) > Q_lim && Ty2_index_pca_test(count) < Ty2_lim_pca
        FP_Q(count) = 1;
    elseif Q_index_test(count) < Q_lim && Ty2_index_pca_test(count) > Ty2_lim_pca
        FN_Q(count) = 1;
    end
end

if sum(TP_Q) == 0 && sum(FN_Q) == 0
    FDR_Q = 0
    MAR_Q = 0;
else
    FDR_Q = sum(TP_Q) / (sum(TP_Q) + sum(FN_Q))
    MAR_Q = sum(FN_Q) / (sum(TP_Q) + sum(FN_Q));
end

if sum(FP_Q) == 0 && sum(TN_Q) == 0
    FAR_Q = 0
else
    FAR_Q = sum(FP_Q) / (sum(FP_Q) + sum(TN_Q))
end

Detect_Q = (sum(TP_Q) + sum(FN_Q))/(sum(TP_Q) + sum(FN_Q) + sum(FP_Q) + sum(TN_Q))


figure
subplot(3,1,1)
bar([T2_index_train,T2_index_test])
subplot(3,1,2)
bar([Q_index_train,Q_index_test])
subplot(3,1,3)
bar([phi_index_train,phi_index_test])

