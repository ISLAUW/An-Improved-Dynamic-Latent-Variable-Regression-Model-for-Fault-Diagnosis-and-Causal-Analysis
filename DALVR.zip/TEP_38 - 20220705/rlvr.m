%% ———— rLVR ————
function [T,P,Q,W,C]=rlvr(X0,Y0,a,k)
% a is the number of rLVR factors

[n,m]=size(X0); np=size(Y0,2);

X=zeros(n,m,a); Y=zeros(n,np,a);
X(:,:,1)=X0; Y(:,:,1)=Y0;

for i=1:a
    U(:,i)=Y(:,1,i);
    itererr=1;
    count=1;
    while norm(itererr)>0.000001
        W(:,i)=pinv(X(:,:,i)'*X(:,:,i)+k*eye(size(X(:,:,i)'*X(:,:,i))))*X(:,:,i)'*U(:,i);   
        W(:,i)=W(:,i)/norm(X(:,:,i)*W(:,i));
        T(:,i)=X(:,:,i)*W(:,i);
        Q(:,i)=Y(:,:,i)'*X(:,:,i)*W(:,i); Q(:,i)=Q(:,i)/norm(Q(:,i));      
%        Q(:,i)=Y(:,:,i)'*(U(:,i)-T(:,i)); Q(:,i)=Q(:,i)/norm(Q(:,i));  %        效果不佳
%        [vec2,val2]=eig(Y(:,:,i)'*X(:,:,i)*pinv(X(:,:,i)'*X(:,:,i)+k*eye(size(X(:,:,i)'*X(:,:,i))))*X(:,:,i)'*Y(:,:,i)); 
%        val2=diag(val2); [val2,ind2]=sort(val2,'descend'); Q(:,i)=vec2(:,ind2(1));
        U(:,i)=Y(:,:,i)*Q(:,i);            
        itererr=T(:,i)-X(:,:,i)*pinv(X(:,:,i)'*X(:,:,i)+k*eye(size(X(:,:,i)'*X(:,:,i))))*X(:,:,i)'*U(:,i)/norm(X(:,:,i)*pinv(X(:,:,i)'*X(:,:,i)+k*eye(size(X(:,:,i)'*X(:,:,i))))*X(:,:,i)'*U(:,i));
        norm(itererr)        
        if count>500
            break
        else
            count=count+1;
        end
    end
    P(:,i)=X(:,:,i)'*T(:,i)/(T(:,i)'*T(:,i));
    C(:,i)=Y(:,:,i)'*T(:,i)/(T(:,i)'*T(:,i));
    X(:,:,i+1)=X(:,:,i)-T(:,i)*P(:,i)';
    Y(:,:,i+1)=Y(:,:,i)-T(:,i)*C(:,i)';
end
