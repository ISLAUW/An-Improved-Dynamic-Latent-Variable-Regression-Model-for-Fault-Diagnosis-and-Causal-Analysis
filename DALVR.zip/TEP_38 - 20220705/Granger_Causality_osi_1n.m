function [variable_osi, osi, C, no_cause_x1, no_cause_x2] = Granger_Causality_osi_1n (X0, X1, Y1, alpha, max_lag, l, gamma_w, gamma_beta, gamma_delta, s, d)

[n,m] = size(X1); np = size(Y1,2);

%% ———— OSI ————
% ———— DALVR ————
[P1, Q, C, W, Beta, Delta, Y1_debug] = darlvr(X1,Y1,l,gamma_w,gamma_beta,gamma_delta,s,d);
g = max(s,d); 
T1 = X1 * P1;
Lambda = 1/(n-1) * T1'* T1;


for i = 1:m
    for j = 1:l
        osi_j(i,j) = Lambda(j,j) * (sum(P1(i,:))).^2; %literature:yuan tao
    end
    osi(i) = sum(osi_j(i,:));
end

[max_osi,variable_osimax] = max(osi);
%control_limit = 122;  % IDV 1: k = 165
%control_limit = 3000; % IDV 1: k = 200
control_limit = 0; % IDV 1: k = 600
%control_limit = 1/10 * max_osi; % IDV 5: k = 161
%control_limit = 1/14 * max_osi; % IDV 5: k = 200
%control_limit = 1/17 * max_osi; % IDV 5: k = 600


figure;
bar(osi, 'b');   
hold on
plot(control_limit * ones(1,m))
set(gca, 'xtick', [1:1:m], 'xticklabel', {'1','4','5','6','7','9','10','11','12','13','14','15','16','17','18','19','20','25','27','28','29','30','32','33'}) % IDV1: k=600
hold all
title('OSI');   
xlabel('No. of Variables'); 

variable_osi = zeros(0,0);
for i = 1:m
    if osi(i) > control_limit
        variable_osi = [variable_osi i];
    end
end

%% ———— Granger Causality Among X ————
C = nchoosek(variable_osi,2); % 210 2

no_cause_x1 = zeros(1,size(C,1)); no_cause_x2 = zeros(1,size(C,1));
for k = 1:size(C,1)
    a = C(k,1); b = C(k,2);    
    x = X0(:,a); y = X0(:,b);
    
    [F1(k),c_v1(k)] = granger_causality(y, x, alpha, g, l, gamma_w, gamma_beta, gamma_delta, s, d); % effect cause
    if F1(k) > c_v1(k)
        no_cause_x1(k) = 1;
    end
    
    [F2(k),c_v2(k)] = granger_causality(x, y, alpha, g, l, gamma_w, gamma_beta, gamma_delta, s, d);
    if F2(k) > c_v2(k)
        no_cause_x2(k) = 1;
    end        
end

[xn, yn] = location (variable_osi);

% ———— Causality_map ————
figure
for k = 1:size(C,1)
    a0 = C(k,1); b0 = C(k,2);
    for i = 1:length(variable_osi)
        if a0 == variable_osi(i)
            a1 = i;
        end
        if b0 == variable_osi(i)
            b1 = i;
        end
    end    

    if no_cause_x1(k) == 0        
        c1 = [xn(a1) xn(b1)]; c2 = [yn(a1) yn(b1)];
        line(c1, c2,'Color','red','LineStyle','--')

        %c1_x = xn(a1);
        %c1_y = xn(b1);
        %c2_x = yn(a1);
        %c2_y = yn(b1);
        %arrow_1 = annotation('arrow',[c1_x c2_x], [c1_y c2_y]);
        %arrow_1.Position = dimen;
        %arrow_1.Color = [1 0 0];
        %arrow_1.LineWidth = 1;
        %arrow_1.HeadStyle = 'vback3';

        axis equal
    end
    
    if no_cause_x2(k) == 0
        c3 = [xn(b1) xn(a1)]; c4 = [yn(b1) yn(a1)];
        line(c3, c4,'Color','blue','LineStyle','--')

        %c1_x = xn(a1);
        %c1_y = xn(b1);
        %c2_x = yn(a1);
        %c2_y = yn(b1);
        %arrow_2 = annotation('arrow',[c2_x c1_x], [c2_y c1_y]);
        %arrow_2.Position = dimen;
        %arrow_2.Color = [0 0 1];
        %arrow_2.LineWidth = 1;
        %arrow_2.HeadStyle = 'vback3';
        axis equal
    end
end



%% ———— Plotting ————
%X_tag = zeros(m,1);
%for i = 1:m
%    X_tag(i) = i;
%end

%for j = 1:p
%    figure;
%    histogram(F(:,j),m);
%    bar(X_tag,F(:,j),'b');    
%    hold all
%    title('Distribution of F');    
%    xlabel('No. of Variables');  
%    ylabel('F');
%end

%figure;
%bar(osi, 'b');   
%hold on
%plot(control_limit * ones(1,m))
%hold all
%title('OSI');   
%xlabel('No. of Variables'); 

for i = 1:length(variable_osi)
    xf(i) = i;
end
yf_0 = zeros(1,length(variable_osi)); 

yf_0 = [-2	-5	-1	-9	-3	8	3	-4	12	-5	-1	-1	3	4	8	-1	-6	12	11	0	-6	-2	-4	0	0	-7	-3	-15	-1	8	10	-4	4]; 

%[max_varibles,variables_max] = max(variables);
%for i = 1 : length(variables)
%    osi_f(i) = osi(variables(i)) / osi(variables_max);
%    yf(i) = osi_f(i) * yf_0(i);
%end

%yf = zeros(1,length(variable_osi)); 
%for i = 1 : length(variable_osi)
    %osi_f(i) = osi(variable_osi(i)) / osi(variable_osimax);
    %yf(i) = osi_f(i) * yf_0(i);
%end

% weighted causal flows
%figure;
%bar(xf, yf, 'b');  
%set(gca, 'xticklabel', {'3','4','7','8','11','20','27','28'}) % IDV 1: k = 165
%set(gca, 'xtick', [1:1:length(variable_osi)], 'xticklabel', {'7','10','11','13','16','18','19','20','22','25','27','28','31'}) % IDV 5: k = 200
%hold all
%title('Causal Flow of Variables');    
%xlabel('No. of Variables');  

% traditional causal flows
figure;
bar(xf, yf_0, 'b');
set(gca, 'xticklabel', {'1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33'}) 
hold all
title('Causal Flow of Variables');    
xlabel('No. of Variables'); 