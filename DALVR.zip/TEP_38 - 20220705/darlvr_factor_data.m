% ———— Determine a,kappa,s by Cross-Validation (CV) ————
% a -- the number of latent variables
% kappa -- the parameter of regularization term
% s -- lags

clear all;
close all;
clc;

%% ———— Training Data: Normal Data ————
% ———— Training Data: IDV(0) ————
load d00_te.dat;
% —— Training Data ——
T0 = 5; 
n = size(d00_te,1)/T0;
X0 = zeros(n,33); Y0 = zeros(n,1); 

for j = 1:n
    X0(j,:) = [d00_te((T0*j),1:22),d00_te((T0*j),42:52)]; 
    Y0(j,:) = d00_te((T0*j),38);    
end

% ———— Autoscale the data ————
X1 = autos(X0); Y1 = autos(Y0);

tic
%% ———— Determine a,kappa by Cross-Validation (CV) ————
[a,gamma_w,gamma_beta,gamma_delta,s,d] = darlvr_factor(X1,Y1);
toc

save darlvr_factor_data a gamma_w gamma_beta gamma_delta s d